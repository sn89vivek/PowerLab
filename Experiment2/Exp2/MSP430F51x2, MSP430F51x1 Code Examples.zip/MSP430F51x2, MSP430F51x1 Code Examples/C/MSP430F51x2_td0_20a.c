//******************************************************************************
//  MSP430F51x2 Demo - TimerD0, Hi-Res Free Running mode, PWM TD0.0-2, TDCLK = 64Mhz
//
//  Description: This code example shows how to configure TimerD in Hi-Res 
//  Free Running mode. The TD0HCTL1 register with the TDHCLKTRIMx, TDHCLKSRx and 
//  TDHCLKRx bit settings are configured with the calibration data in the TLV 
//  table. 
//
//  SMCLK = MCLK = DCOclock = default DCO; TDCLK(TLV Cal Data)= 64Mhz
//  Note: 1. TDHMx=00(8x) should be used to use the 64Mhz TimerD TLV calibration data
//        2. Use code example with hal_tlv.c and hal_tlv.h files to read the TimerD TLV data 
//
//                 MSP430F51x2
//             -----------------
//         /|\|              XIN|-
//          | |                 | 
//          --|RST          XOUT|-
//            |                 |
//            |       P1.6/TD0.0|--> CCR0 - 50% dutycycle; PWM period = (2 x 128)/64MHz~ 4us = 250kHz
//            |       P1.7/TD0.1|--> CCR1 - 25% dutycycle; ON period ~ 32/64MHz~ 500ns
//            |       P2.0/TD0.2|--> CCR2 - 75% dutycycle; ON period ~ 96/64MHz~ 1500ns
//
//  B. Nisarga
//  Texas Instruments Inc.
//  May 2011
//  Built with CCS v4 and IAR Embedded Workbench Version: 4.21
//******************************************************************************

#include "msp430f5172.h"
#include "hal_tlv.h"

void main(void)
{
  struct s_TLV_Timer_D_Cal_Data * pTD0CAL;  // Structure initialized in tlv.h
  unsigned char bTD0CAL_bytes;                  
  
  WDTCTL = WDTPW + WDTHOLD;                 // Stop WDT
  
  // Configure TimerD in Hi-Res Free Running Mode
  Get_TLV_Info(TLV_TIMER_D_CAL, 0, &bTD0CAL_bytes, (unsigned int **) &pTD0CAL); 
                                            //Get TimerD0 Cal Values (instance 0)
  if(bTD0CAL_bytes == 0x0)
  {
      // No TimerD free running cal data found
      while(1);                             // Loop here
  }  
  TD0HCTL1 = pTD0CAL->TDH0CTL1_64;          // Read the 64Mhz TimerD TLV Data                 

  TD0CTL1 |= TDCLKM_1;                      // Select Hi-res local clock
  TD0HCTL0 = TDHEN + TDHM_0;                // CALEN=0 => free running mode; enable Hi-res mode 
                                            // THDMx = 00 => 8x
  // Configure TD0.x GPIO pins
  P1SEL |= BIT6 + BIT7;                     // P1.6,7 option select
  P1DIR |= BIT6 + BIT7;                     // P1.6,7 output
  P2SEL |= BIT0;                            // P2.0 options select
  P2DIR |= BIT0;                            // P2.0 output   
  
  // Configure the CCRx blocks
  TD0CCTL0 = OUTMOD_4;                      // CCR0 toggle
  TD0CCR0 = 128-1;                          // PWM Period/2
  TD0CCTL1 = OUTMOD_6;                      // CCR1 toggle/set
  TD0CCR1 = 32;                             // CCR1 PWM duty cycle
  TD0CCTL2 = OUTMOD_6;                      // CCR2 toggle/set
  TD0CCR2 = 96;                             // CCR2 PWM duty cycle
  TD0CTL0 |= MC_1 + TDCLR;                  // up-mode, clear TDR, Start timer
  
  __bis_SR_register(LPM0_bits + GIE);       // Enter LPM0
  __no_operation();                         // For debugger  
}
  
